
"use strict";

let target_srv = require('./target_srv.js')

module.exports = {
  target_srv: target_srv,
};
