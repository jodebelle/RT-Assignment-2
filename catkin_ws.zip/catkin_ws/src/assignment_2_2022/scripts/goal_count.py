#! /usr/bin/env python3
import rospy
import actionlib
import actionlib.msg
import assignment_2_2022.msg

from assignment_2_2022.srv import target_srv, target_srvResponse

goal_count = {'reached': 0, 'cancelled': 0}

def result(msg):
    global goal_reached_callback, goal_cancelled_callback
    
    status=msg.status.status

    if status == 2: #goal preempted
        goal_count['cancelled'] += 1
    elif status == 3: #goal reached
        goal_count['reached'] += 1

def goal_callback(req):
    print ("Number of goals reached:", goal_count['reached'])
    print ("Number of goals cancelled:", goal_count['cancelled'])
    return target_srvResponse (success = True, message = "Goal count printed")

def goal_reached_callback():
    goal_count['reached'] += 1

def goal_cancelled_callback():
    goal_count['cancelled'] += 1

#goal_reached_subscriber = rospy.Subscriber ('goal_reached', Empty, goal_reached_callback)
#goal_cancelled_subscriber = rospy.Subscriber ('goal_cancelled', Empty, goal_cancelled_callback)

def data(req):
    global goal_reached_callback, goal_cancelled_callback
    return target_srvResponse(goal_reached_callback, goal_cancelled_callback)

def main():
    
    rospy.init_node('goal_count')
    srv= rospy.Service('goal_count', target_srv, goal_callback)
    subscriber_result = rospy.Subscriber('/robot_target/result', assignment_2_2022.msg.PlanningActionResult, result)
    rospy.spin()

if __name__ == "__main__":
    main()

