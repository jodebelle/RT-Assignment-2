#! /usr/bin/env python3
import rospy
import sys
import select
import actionlib
import actionlib.msg
import assignment_2_2022.msg

from assignment_2_2022.srv import target_srv
from nav_msgs.msg import Odometry
from assignment_2_2022.msg import PoseVelocity
from geometry_msgs.msg import Point, Pose, Twist 

def call_srv(): #function to call service node
    rospy.wait_for_service ('srv')
    srv = rospy.ServiceProxy ('srv', target_srv)
    resp = srv()
    print("Number of goals cancelled", resp.cancelled)
    print("Number of goals reached", resp.reached)
  

def pub_data (msg): #function to publish information on position
    global pub

    PoseVelocity_output = PoseVelocity() #custom msg
    position = msg.pose.pose.position #get position
    velocity = msg.twist.twist.linear #get twist

    #parameters
    PoseVelocity_output_px = position.x
    PoseVelocity_output_py = position.y
    PoseVelocity_output_vx = velocity.x
    PoseVelocity_output_vy = velocity.y

    pub.publish(PoseVelocity_output) #publish message


def action_client():
        # Initialize the action client

        action_client = actionlib.SimpleActionClient("/reaching_goal", assignment_2_2022.msg.PlanningAction)

        action_client.wait_for_server()

        x=0
        y=0
        
        while not rospy.is_shutdown():
            print (" Enter the coordinates x and y")
            x=float(input("Enter a goal x: "))
            y=float(input("Enter a goal y: "))
        
            #target position
            goal = assignment_2_2022.msg.PlanningGoal()
            goal.target_pose.pose.position.x = x
            goal.target_pose.pose.position.y = y

            target_x = x
            target_y = y

            action_client.send_goal(goal)

    #to cancel target
def cancel_target(self):

    print("press x to cancel the target")
    input=select.select ([sys.stdin],  [], [], 3) [0] #give user 3 seconds to cancel goal

    if input:
        i = sys.stdin.readline().rstrip()
        if(i=="x"):
            self.action_client.cancel_goal()
            print("The goal has been cancelled")
            self.target_x = None
            self.target_y = None

def main():
    rospy.init_node("action_client")
    global pub

    #publisher for custom message
    pub = rospy.Publisher("/PoseVelocity", PoseVelocity, queue_size=10)


    #subscriber for /odom
    odom_sub = rospy.Subscriber("/odom", Odometry, pub_data)
    
    action_client()
    
if __name__ == '__main__':
        main()


    
